#Juicebox being nervous as usual
print("I'm nervous, uh.. I mean Juicebox!")

#Ask user to enter their name
user_name = input("What is your name?\n")

#Juicebox is very sweet
print("Okay " + user_name)

#Ask user where they grew up
city = input("What city did you grow up in?\n")

#This is a tough one. Ask for their favorite pet name. This could take a while Juicebox. Hang tight
pet_name = input("What was your favorite pet's name growing up?\n")

#Generate users band name! Now they can go rock the world!!
print("Your band name would be " + city + " " + pet_name + "!")

print("\nNow go rock the world and leave me be. Juicebox is thirsty!")
